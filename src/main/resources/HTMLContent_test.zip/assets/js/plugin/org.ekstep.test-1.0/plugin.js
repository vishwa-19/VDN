Plugin.extend({
	init: function(){
		console.info('Test plugin init is done');
	},
    initialize: function() {
        console.info('org.ekstep.test-1.0 plugin is loaded..');
    }
});

//# sourceURL=testPlugin.js