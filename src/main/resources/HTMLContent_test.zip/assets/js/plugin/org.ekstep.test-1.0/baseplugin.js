var Plugin = Class.extend({
 
init: function(){
	console.info('base plugin init');
},
initialize: function(){
	console.info('Base plguin initialize');
}


});